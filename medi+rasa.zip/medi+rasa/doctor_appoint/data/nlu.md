## intent:Agra
- /Agra

## intent:Delhi
- /Delhi
- /Delhi

## intent:Dermatalogy
- /Dermatalogy
- /Dermatalogy
- /Dermatalogy

## intent:FeedBack
- /FeedBack
- /FeedBack

## intent:Female
- /Female
- /Female

## intent:FirstVisit
- /FirstVisit
- /FirstVisit
- /FirstVisit

## intent:FollowupVisit
- /FollowupVisit
- /FollowupVisit
- /FollowupVisit
- /FollowupVisit

## intent:GeneralSurgery
- /GeneralSurgery
- /GeneralSurgery

## intent:JamesSmith
- /JamesSmith

## intent:JustinaPetraityte
- /JustinaPetraityte
- /JustinaPetraityte

## intent:Kolkata
- /Kolkata
- /Kolkata

## intent:Lucknow
- /Lucknow
- /Lucknow

## intent:Male
- /Male
- /Male
- /Male
- /Male
- /Male

## intent:MohdSarfarazKhan
- /MohdSarfarazKhan
- /MohdSarfarazKhan
- /MohdSarfarazKhan

## intent:Morethan15min
- /Morethan15min

## intent:No
- /No
- /No
- /No
- /No
- /No
- no

## intent:Nope
- /Nope

## intent:NotSure
- /NotSure

## intent:OnlineAppointment
- /OnlineAppointment
- /OnlineAppointment
- /OnlineAppointment
- /OnlineAppointment
- /OnlineAppointment
- /OnlineAppointment
- /OnlineAppointment

## intent:Ontime
- /Ontime

## intent:Orthopedics
- /Orthopedics

## intent:RohitSharma
- /RohitSharma

## intent:Today
- /Today
- /Today

## intent:Tomorrow
- /Tomorrow
- /Tomorrow
- /Tomorrow

## intent:WithinNext14Days
- /WithinNext14Days

## intent:WithinNext7Days
- /WithinNext7Days
- /WithinNext7Days

## intent:Yes
- /Yes
- /Yes
- yes

## intent:YesOnTime
- /YesOnTime

## intent:affirm
- /Yes
- yes
- indeed
- of course
- that sounds good
- correct

## intent:deny
- /No
- no
- never
- I don't think so
- don't like that
- no way
- not really

## intent:feedback_info
- abc@xyz
- [abc@xyzz](email)

## intent:feedback_rate
- 10
- [5](rating)
- [10](rating)

## intent:goodbye
- bye
- goodbye
- see you around
- see you later

## intent:greet
- hey
- hello
- hi
- good morning
- good evening
- hey there
- hi
- hiii
- hi
- hi
- hi
- hi
- hii
- hi
- hi

## intent:information
- abc
- [1234567890](number)
- 22/09/1992
- abc@xyz.com
- [abc](information)
- 1234567890
- 26/09/1995
- abc@xyz.com
- [sarfaraz](information)
- [1234567890](number)
- 26 september 2019
- abc@xyz.com
- [rohit](information)
- 12345678901
- 26/09/1995
- abc@xyz.com
- [abcd](name)
- 9998887765
- 12/12/2002
- abc@xyz.com
- [md sarfaraz](information)
- 9998989786
- 26/09/1995
- abc@xyz.com
- [mohd](information)
- 1235678998
- 26/09/1992
- abc@xyz.com
- mohd
- 1235678998
- 26/09/1992
- abc@xyz.com
- sadf
- [1234567890](number)
- 2 sept 2012
- abc@gmail.com
- abc@xyz.com

## intent:location
- /Delhi
- /Lucknow
- /Kolkata
- /Agra
- [Delhi](location)

## intent:mood_great
- perfect
- very good
- great
- amazing
- wonderful
- I am feeling very good
- I am great
- I'm good

## intent:mood_unhappy
- sad
- very sad
- unhappy
- bad
- very bad
- awful
- terrible
- not very good
- extremely sad
- so sad

## intent:other_info
- ABCD
